# Sleep Compression Tracker

> *Consolidate. Expand. Rest.*

---

## Current Status

| Field | Value |
|---|---|
| **Phase** | `baseline` |
| **Fixed wake time** | — |
| **Current bedtime** | — |
| **TIB target** | — min |
| **Avg TST (baseline)** | — min |
| **Avg SE% (this week)** | — % |
| **Consecutive days ≥85%** | — / 5 |

---

## Phase Guide

| Phase | What you're doing | When to move on |
|---|---|---|
| **Baseline** | Track sleep as-is for 7–14 days | Once you have avg TST |
| **Compression** | TIB = avg TST + 30 min, hold fixed wake time | SE% ≥85% for 5 consecutive days |
| **Expansion** | Add 15 min TIB at a time | SE% stays ≥85% after each step |
| **Stable** | You've found your natural sleep need | Maintain and enjoy |

---

## Quick Rules

- **Never go below 5.5 hrs TIB**
- **Wake time is fixed — no exceptions, no sleeping in**
- **Only get into bed when sleepy** (not just when it's "time")
- **No naps during compression phase**
- **Bed = sleep only**

---

## SE% Reference

| SE% | Status | Action |
|---|---|---|
| ≥ 90% | 🟢 Excellent | Expand if 5-day streak |
| 85–89% | 🟡 Good | Hold, working well |
| 80–84% | 🟠 Marginal | Hold, don't expand yet |
| < 80% | 🔴 Poor | Consider slight compression |

---

## Log Links

### Baseline
*Create logs: [[daily_logs/YYYY-MM-DD]]*

### Weekly Reviews
*[[weekly_reviews/Week 1]] · [[weekly_reviews/Week 2]] · [[weekly_reviews/Week 3]]*

---

## SE% Trend (Manual Sparkline)

```
Week 1: ░░░░░░░
Week 2: ░░░░░░░
Week 3: ░░░░░░░
Week 4: ░░░░░░░
```
*Fill each cell: 🟢 ≥85  🟡 80–84  🔴 <80*

---

> "Sleep pressure is the mechanism. The window is the tool. Consistency is the cure."
