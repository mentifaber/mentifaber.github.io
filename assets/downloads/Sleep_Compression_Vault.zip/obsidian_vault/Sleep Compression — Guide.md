# Sleep Compression — Protocol Reference

---

## Step 1 · Baseline (Weeks 1–2)

Track every morning without changing anything. Log:
- Bed time
- Estimated sleep onset time
- Number of wake-ups + total minutes awake
- Final rise time

Calculate **TST** (Total Sleep Time) and **TIB** (Time in Bed) in minutes.

After 7–14 days: compute your **average TST**.

---

## Step 2 · Set Your Compression Window

```
New TIB = Average TST + 30 min
Minimum TIB = 330 min (5.5 hrs)
```

Pick a **fixed wake time** → count back your TIB → that's your new bedtime.

> Example: avg TST = 330 min, wake at 7:00am
> TIB = 360 min = 6 hrs → bedtime = 1:00am

---

## Step 3 · Hold the Window

Stay in the window for 1–2 weeks. Every day:
- Get up at your wake time regardless of how little you slept
- Only get into bed when genuinely sleepy (but still rise on time)
- No naps
- Track SE% daily

---

## Step 4 · Expand When Ready

**Trigger:** SE% ≥ 85% for **5 consecutive days**

**Action:** Move bedtime **15 minutes earlier** (TIB +15 min)

Hold the new window. Check SE% again. Repeat.

If SE% drops below 80% for a full week → compress back by 15 min.

---

## Step 5 · Stabilize

Keep expanding until you feel rested and SE% stays healthy.
Most people land at 7–8 hrs naturally.

At this point: maintain your wake time, let bedtime be flexible within ~30 min.

---

## Formulas

```
SE%  = (TST ÷ TIB) × 100
TST  = TIB − (sleep onset delay) − (total wake time)
TIB  = rise time − bed time (in minutes)
```

---

## Red Flags to Watch

| Symptom | Likely cause | Fix |
|---|---|---|
| Can't fall asleep at new bedtime | Not sleepy enough | Wait until sleepy, still rise on time |
| Waking very early and can't sleep | Compression working (temporary) | Push through, it improves |
| Daytime impairment is severe | TIB too low | Don't go below 5.5 hrs |
| SE% plateaued below 85% for weeks | Other factor (anxiety, apnea, etc.) | Consider professional eval |

---

*← [[Sleep Compression — Home]]*
