---
date: {{date:YYYY-MM-DD}}
day: {{date:dddd}}
phase: baseline
tags: [sleep, "#baseline"]
---

# Sleep Log — {{date:MMMM D, YYYY}}

## Entry

| Field | Value |
|---|---|
| 🛏 Bed time | |
| 😴 Estimated sleep onset | |
| 🌙 Wake-ups (count + total min) | |
| ⏰ Final rise time | |
| 💤 Total Sleep Time (TST) | min |
| 🕐 Time in Bed (TIB) | min |
| 📊 Sleep Efficiency (SE%) | % |
| 🌡 Feel rating (1–10) | |

> **SE% formula:** `TST ÷ TIB × 100`

---

## Notes

*How did sleep feel? Anything notable — stress, alcohol, late eating, exercise?*

---

## Phase Check

- [ ] SE% ≥ 85 (Day 1 of 5-day streak)
- [ ] SE% ≥ 85 (Day 2)
- [ ] SE% ≥ 85 (Day 3)
- [ ] SE% ≥ 85 (Day 4)
- [ ] SE% ≥ 85 (Day 5 → **expand TIB by 15 min**)

---

*[[Weekly Review]]*
