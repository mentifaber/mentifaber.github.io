---
week: {{date:YYYY-[W]WW}}
date_range: {{date:MMM D}} – {{date+6d:MMM D, YYYY}}
tags: [sleep, weekly-review]
---

# Weekly Sleep Review — {{date:YYYY [W]WW}}

## Summary Table

| Date | TST (min) | TIB (min) | SE% | Feel |
|------|-----------|-----------|-----|------|
| Mon  |           |           |     |      |
| Tue  |           |           |     |      |
| Wed  |           |           |     |      |
| Thu  |           |           |     |      |
| Fri  |           |           |     |      |
| Sat  |           |           |     |      |
| Sun  |           |           |     |      |
| **Avg** |        |           |     |      |

---

## Phase Assessment

**Current phase:** `baseline / compression / expansion / stable`
**Current TIB window:** `__:__ → __:__`
**Fixed wake time:** `__:__`

### SE% Streak
Days at ≥85%: `__ / 7`
Consecutive days: `__`

> [!se-good] Ready to expand?
> 5 consecutive days ≥ 85% → move bedtime **15 min earlier**

---

## Observations

*What worked? What didn't? Any patterns?*

---

## Next Week Plan

- [ ] Wake time: `__:__` (non-negotiable)
- [ ] Bedtime: `__:__`
- [ ] TIB target: `__ min`
- [ ] No naps: ✅ / ❌
- [ ] Expand TIB this week: yes / no

---

*← [[Weekly Review]] · [[Weekly Review]] →*
